/*
  SlidFix calculator prototype
  IMPORTANT: placement spacing below is UX/demo logic, not an engineering specification.
  Replace engineering constants after validated tests and installation rules are approved.
*/
const ENGINEERING = {
  packSize: 10,
  screwsPerUnit: 2,
  standardVerticalPitchMm: 500,
  denseVerticalPitchMm: 350,
  edgeClearanceMm: 180,
  openingClearanceMm: 110,
};

const state = {
  preset: 'window-center',
  pattern: 'standard',
  density: 'standard',
  wallWidth: 6.0,
  wallHeight: 2.8,
  boardWidth: 125,
  battenSpacing: 600,
  openingWidth: 1.8,
  openingHeight: 1.2,
};

const $ = (id) => document.getElementById(id);
const svg = $('wallSvg');
const NS = 'http://www.w3.org/2000/svg';

function el(tag, attrs = {}, parent = svg) {
  const n = document.createElementNS(NS, tag);
  Object.entries(attrs).forEach(([k,v]) => n.setAttribute(k, v));
  if (parent) parent.appendChild(n);
  return n;
}
function text(x,y,str,attrs={}){
  const t=el('text',{x,y,fill:'#dfe5e9','font-size':attrs.size||14,'font-family':'Inter,system-ui,sans-serif','font-weight':attrs.weight||600,'text-anchor':attrs.anchor||'start'});
  t.textContent=str; return t;
}
function clamp(v,min,max){return Math.max(min,Math.min(max,v));}

function getOpenings(){
  const W=state.wallWidth,H=state.wallHeight;
  const ow=clamp(state.openingWidth,0.3,Math.max(.3,W*.75));
  const oh=clamp(state.openingHeight,0.3,Math.max(.3,H*.85));
  if(state.preset==='blank') return [];
  if(state.preset==='window-center') return [{x:(W-ow)/2,y:H*.26,w:ow,h:Math.min(oh,H*.55),kind:'window'}];
  if(state.preset==='door-left') return [{x:W*.08,y:0,w:Math.min(ow,W*.28),h:Math.min(Math.max(oh,H*.72),H*.88),kind:'door'}];
  if(state.preset==='door-center') return [{x:(W-Math.min(ow,W*.28))/2,y:0,w:Math.min(ow,W*.28),h:Math.min(Math.max(oh,H*.72),H*.88),kind:'door'}];
  if(state.preset==='two-windows'){
    const ww=Math.min(ow,W*.22), hh=Math.min(oh,H*.42);
    return [
      {x:W*.14,y:H*.30,w:ww,h:hh,kind:'window'},
      {x:W*.64,y:H*.30,w:ww,h:hh,kind:'window'}
    ];
  }
  return [];
}

function pointInsideOpening(x,y,o,clearM){
  return x>o.x-clearM && x<o.x+o.w+clearM && y>o.y-clearM && y<o.y+o.h+clearM;
}

function calculateLayout(){
  const Wmm=state.wallWidth*1000,Hmm=state.wallHeight*1000;
  const edge=ENGINEERING.edgeClearanceMm;
  const pitchX=clamp(state.battenSpacing,250,1200);
  const pitchY=state.density==='dense'?ENGINEERING.denseVerticalPitchMm:ENGINEERING.standardVerticalPitchMm;
  const openings=getOpenings();
  const clear=ENGINEERING.openingClearanceMm/1000;
  const pts=[];
  let row=0;
  for(let y=edge; y<=Hmm-edge; y+=pitchY,row++){
    const offset=(state.pattern==='staggered' && row%2===1)?pitchX/2:0;
    for(let x=edge+offset; x<=Wmm-edge; x+=pitchX){
      const xm=x/1000,ym=y/1000;
      if(!openings.some(o=>pointInsideOpening(xm,ym,o,clear))) pts.push({x:xm,y:ym});
    }
  }
  return {points:pts,pitchX,pitchY,openings};
}

function drawWall(){
  svg.innerHTML='';
  const {points,openings}=calculateLayout();
  const VW=1000,VH=540;
  const pad={l:72,r:34,t:60,b:54};
  const x0=pad.l,y0=pad.t,w=VW-pad.l-pad.r,h=VH-pad.t-pad.b;
  const sx=w/state.wallWidth, sy=h/state.wallHeight;
  const wall=(x)=>x0+x*sx, wy=(y)=>y0+h-y*sy;

  // defs / wood texture
  const defs=el('defs');
  const grad=el('linearGradient',{id:'wood','x1':'0','y1':'0','x2':'1','y2':'0'},defs);
  el('stop',{offset:'0%','stop-color':'#8e5f38'},grad); el('stop',{offset:'45%','stop-color':'#bd8753'},grad); el('stop',{offset:'100%','stop-color':'#9c6a3e'},grad);
  const shadow=el('filter',{id:'shadow',x:'-20%',y:'-20%',width:'140%',height:'140%'},defs); el('feDropShadow',{dx:'0',dy:'8',stdDeviation:'10','flood-color':'#000','flood-opacity':'.4'},shadow);

  el('rect',{x:x0,y:y0,width:w,height:h,rx:4,fill:'url(#wood)',stroke:'#65717a','stroke-width':1,filter:'url(#shadow)'});
  // vertical cladding boards purely visual
  const boardM=state.boardWidth/1000;
  for(let bx=boardM;bx<state.wallWidth;bx+=boardM){
    const X=wall(bx); el('line',{x1:X,y1:y0,x2:X,y2:y0+h,stroke:'#6d472b','stroke-opacity':.52,'stroke-width':1});
  }
  // grain lines
  for(let i=0;i<18;i++){
    const gy=y0+((i+1)/(19))*h;
    el('path',{d:`M ${x0} ${gy} C ${x0+w*.24} ${gy-4} ${x0+w*.55} ${gy+5} ${x0+w} ${gy-2}`,fill:'none',stroke:'#d4a16b','stroke-opacity':.10,'stroke-width':2});
  }

  // openings
  openings.forEach(o=>{
    const ox=wall(o.x), oy=wy(o.y+o.h), ow=o.w*sx, oh=o.h*sy;
    el('rect',{x:ox,y:oy,width:ow,height:oh,fill:o.kind==='door'?'#10171c':'#1c2730',stroke:'#090d10','stroke-width':9,rx:2});
    if(o.kind==='window'){
      el('line',{x1:ox+ow/2,y1:oy+4,x2:ox+ow/2,y2:oy+oh-4,stroke:'#0b1115','stroke-width':5});
      el('path',{d:`M${ox+8} ${oy+oh*.7} Q ${ox+ow*.3} ${oy+oh*.45} ${ox+ow*.55} ${oy+oh*.66} T ${ox+ow-8} ${oy+oh*.54}`,fill:'none',stroke:'#496779','stroke-opacity':.5,'stroke-width':2});
    } else {
      el('circle',{cx:ox+ow*.82,cy:oy+oh*.5,r:5,fill:'#bfc8cf'});
    }
  });

  // placement points
  points.forEach(p=>{
    const X=wall(p.x),Y=wy(p.y);
    el('circle',{cx:X,cy:Y,r:6.4,fill:'#f4f6f7',stroke:'#ff302a','stroke-width':3});
    el('circle',{cx:X,cy:Y,r:1.8,fill:'#ff302a'});
  });

  // dimensions
  const dimY=y0-24; el('line',{x1:x0,y1:dimY,x2:x0+w,y2:dimY,stroke:'#d6dde2','stroke-width':1.4});
  el('path',{d:`M${x0} ${dimY} l10 -5 l0 10 z M${x0+w} ${dimY} l-10 -5 l0 10 z`,fill:'#d6dde2'});
  text(x0+w/2,dimY-8,`${state.wallWidth.toFixed(1)} m`,{anchor:'middle',size:15});
  const dimX=x0-28; el('line',{x1:dimX,y1:y0,x2:dimX,y2:y0+h,stroke:'#d6dde2','stroke-width':1.4});
  el('path',{d:`M${dimX} ${y0} l-5 10 l10 0 z M${dimX} ${y0+h} l-5 -10 l10 0 z`,fill:'#d6dde2'});
  const ht=text(dimX-10,y0+h/2,`${state.wallHeight.toFixed(1)} m`,{anchor:'middle',size:14}); ht.setAttribute('transform',`rotate(-90 ${dimX-10} ${y0+h/2})`);

  // bottom legend
  text(x0,y0+h+35,`${points.length} SlidFix positions · ${state.pattern} · ${state.density} spacing`,{size:12,weight:500});
  updateResults(points.length, openings);
}

function updateResults(unitCount,openings){
  const gross=state.wallWidth*state.wallHeight;
  const openingArea=openings.reduce((s,o)=>s+o.w*o.h,0);
  const net=Math.max(0,gross-openingArea);
  const packs=Math.ceil(unitCount/ENGINEERING.packSize);
  const screws=unitCount*ENGINEERING.screwsPerUnit;
  const courses=Math.ceil((state.wallHeight*1000)/state.boardWidth);
  $('grossArea').textContent=`${gross.toFixed(1)} m²`; $('grossDims').textContent=`${state.wallWidth.toFixed(1)} × ${state.wallHeight.toFixed(1)} m`;
  $('netArea').textContent=`${net.toFixed(1)} m²`; $('boardCourses').textContent=courses; $('boardCourseNote').textContent=`${state.boardWidth} mm boards`;
  $('unitCount').textContent=unitCount; $('packCount').textContent=packs; $('screwCount').textContent=screws;
  $('cartBtn').innerHTML=`ADD ${packs} PACK${packs===1?'':'S'} TO CART <span>→</span>`;
  $('miniPattern').textContent=`${state.pattern.toUpperCase()} · ${state.density.toUpperCase()} · ${state.battenSpacing} mm grid`;
}

function syncFromInputs(){
  state.wallWidth=+($('wallWidth').value)||6; state.wallHeight=+($('wallHeight').value)||2.8;
  state.boardWidth=+($('boardWidth').value)||125; state.battenSpacing=+($('battenSpacing').value)||600;
  state.openingWidth=+($('openingWidth').value)||1.8; state.openingHeight=+($('openingHeight').value)||1.2;
  drawWall();
}

['wallWidth','wallHeight','boardWidth','battenSpacing','openingWidth','openingHeight'].forEach(id=>$(id).addEventListener('input',syncFromInputs));

document.querySelectorAll('[data-preset]').forEach(btn=>btn.addEventListener('click',()=>{
  document.querySelectorAll('[data-preset]').forEach(b=>b.classList.remove('active')); btn.classList.add('active'); state.preset=btn.dataset.preset;
  $('openingFields').style.opacity=state.preset==='blank'?.45:1; drawWall();
}));
document.querySelectorAll('[data-pattern]').forEach(btn=>btn.addEventListener('click',()=>{
  document.querySelectorAll('[data-pattern]').forEach(b=>b.classList.remove('active'));btn.classList.add('active');state.pattern=btn.dataset.pattern;drawWall();
}));
document.querySelectorAll('[data-density]').forEach(btn=>btn.addEventListener('click',()=>{
  document.querySelectorAll('[data-density]').forEach(b=>b.classList.remove('active'));btn.classList.add('active');state.density=btn.dataset.density;drawWall();
}));

$('downloadSvgBtn').addEventListener('click',()=>{
  const clone=svg.cloneNode(true);clone.setAttribute('xmlns',NS);
  const blob=new Blob([new XMLSerializer().serializeToString(clone)],{type:'image/svg+xml'});
  const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='slidfix-wall-layout.svg';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
});
$('downloadJsonBtn').addEventListener('click',()=>{
  const layout=calculateLayout();
  const data={brand:'SlidFix',generatedAt:new Date().toISOString(),state,engineeringDemoConstants:ENGINEERING,openings:layout.openings,unitCount:layout.points.length,packs:Math.ceil(layout.points.length/ENGINEERING.packSize),screws:layout.points.length*ENGINEERING.screwsPerUnit,points:layout.points};
  const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='slidfix-project.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
});
$('cartBtn').addEventListener('click',()=>alert('Demo CTA: connect this button to your ecommerce cart / Shopify / WooCommerce.'));

drawWall();
